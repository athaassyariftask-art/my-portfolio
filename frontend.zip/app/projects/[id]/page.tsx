import '@/app/fun.css'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import ReactMarkdown from 'react-markdown'
import { ArrowLeft, ArrowUpRight } from 'lucide-react'
import ReadingProgress from '@/components/ReadingProgress'
import AdminButton from '@/components/AdminButton'
import EditableBlocks from '@/components/EditableBlocks'
import InlineText from '@/components/InlineText'
import { getDetail, isAdmin } from '@/lib/details'
import { getProject } from '@/lib/projects'

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const p = await getProject(id)
  return p ? { title: p.title, description: p.summary } : {}
}

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const p = await getProject(id) // draft tidak ikut karena Django menyaringnya untuk publik
  if (!p) notFound()
  const [blocks, admin] = await Promise.all([getDetail(`project-${p.id}`), isAdmin()])

  return (
    <main className="min-h-screen bg-[#f7f6f2] text-slate-800">
      <ReadingProgress />
      <article className="mx-auto max-w-3xl px-6 py-16">
        <Link
          href="/#projects"
          className="mb-10 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-slate-500 transition-colors hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" /> Semua project
        </Link>

        <p className="mb-3 font-mono text-xs text-slate-500">{p.date}</p>
        <div className="mb-4">
          <InlineText endpoint={`projects/${p.id}`} field="title" initial={p.title} canEdit={admin} required as="h1"
            className="text-4xl font-extrabold tracking-tight text-slate-900 md:text-5xl" />
        </div>
        <div className="mb-6">
          <InlineText endpoint={`projects/${p.id}`} field="summary" initial={p.summary} canEdit={admin}
            placeholder="Tulis ringkasan singkat (tampil di kartu project)…" className="text-lg text-slate-600" />
        </div>

        <div className="mb-8 flex flex-wrap items-center gap-2">
          {p.tags.map((t) => (
            <span key={t} className="rounded-full bg-slate-100 px-3 py-1 font-mono text-xs text-slate-600">
              {t}
            </span>
          ))}
          {p.demo && (
            <a
              href={p.demo}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 rounded-full bg-slate-900 px-4 py-1.5 text-sm font-semibold text-white hover:bg-blue-600"
            >
              Demo <ArrowUpRight className="h-4 w-4" />
            </a>
          )}
          {p.repo && (
            <a
              href={p.repo}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 rounded-full border border-slate-300 px-4 py-1.5 text-sm font-semibold text-slate-700 hover:border-slate-900"
            >
              Repo <ArrowUpRight className="h-4 w-4" />
            </a>
          )}
        </div>

        {p.cover && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={p.cover} alt={p.title} className="mb-10 w-full rounded-3xl border border-slate-200" />
        )}

        <EditableBlocks
          detailKey={`project-${p.id}`}
          initial={blocks}
          canEdit={admin}
          seedMarkdown={p.description}
          fallback={
        <div className="text-slate-700">
          <ReactMarkdown
            components={{
              h2: ({ node, ...props }) => <h2 className="mb-3 mt-10 text-2xl font-bold text-slate-900" {...props} />,
              h3: ({ node, ...props }) => <h3 className="mb-2 mt-8 text-xl font-bold text-slate-900" {...props} />,
              p: ({ node, ...props }) => <p className="mb-4 leading-relaxed" {...props} />,
              ul: ({ node, ...props }) => <ul className="mb-4 list-disc space-y-1 pl-6" {...props} />,
              ol: ({ node, ...props }) => <ol className="mb-4 list-decimal space-y-1 pl-6" {...props} />,
              a: ({ node, ...props }) => <a className="text-blue-600 underline" {...props} />,
              code: ({ node, ...props }) => (
                <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-sm" {...props} />
              ),
              img: ({ node, ...props }) => (
                // eslint-disable-next-line @next/next/no-img-element, jsx-a11y/alt-text
                <img className="my-6 w-full rounded-2xl border border-slate-200" {...props} />
              ),
            }}
          >
            {p.description}
          </ReactMarkdown>
        </div>
          }
        />
      </article>
      <AdminButton />
    </main>
  )
}
