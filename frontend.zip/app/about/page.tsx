import '@/app/fun.css'
import ReadingProgress from '@/components/ReadingProgress'
import AdminButton from '@/components/AdminButton'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import EditableBlocks from '@/components/EditableBlocks'
import Sections, { pickSections } from '@/components/Sections'
import { getDetail, getDetailContext } from '@/lib/details'
import { getProfile } from '@/lib/profile'
import { getProjects } from '@/lib/projects'
import { defaultSections, getSections } from '@/lib/sections'

export const metadata = { title: 'Tentang saya' }

export default async function About() {
  const [site, projects, sections, aboutBlocks, detail] = await Promise.all([
    getProfile(),
    getProjects(),
    getSections(),
    getDetail('about'),
    getDetailContext(),
  ])
  // Belum ada cerita di database -> pakai contoh bawaan supaya halaman tidak kosong
  const picked = pickSections(sections, 'about')
  const items = picked.length ? picked : pickSections(defaultSections(), 'about')

  return (
    <main
      className="relative min-h-screen overflow-x-hidden bg-[#f7f6f2] text-slate-800"
      style={{ backgroundImage: 'radial-gradient(#d6d3cb 1px, transparent 1px)', backgroundSize: '28px 28px' }}
    >
      <ReadingProgress />
      <div className="relative z-10 mx-auto max-w-3xl px-6 pb-12 pt-16">
        <Link
          href="/"
          className="mb-10 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-slate-500 transition-colors hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" /> Beranda
        </Link>
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-slate-500">
          {site.role} · {site.affiliation}
        </p>
        <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-slate-900 md:text-5xl">
          Tentang <span className="text-blue-600">{site.name}</span>
        </h1>
      </div>

      <div className="relative z-10 mx-auto max-w-3xl px-6 pb-16">
        <EditableBlocks
          detailKey="about"
          initial={aboutBlocks}
          canEdit={detail.admin}
        />
      </div>

      <Sections items={items} projects={projects} narrow detail={detail} />

      <div className="relative z-10 mx-auto max-w-3xl px-6 pb-20">
        <Link
          href="/#contact"
          className="inline-flex rounded-full bg-slate-900 px-7 py-3.5 font-semibold text-white transition-colors hover:bg-blue-600"
        >
          Hubungi saya
        </Link>
      </div>
      <AdminButton />
    </main>
  )
}
