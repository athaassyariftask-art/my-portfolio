import '@/app/fun.css'
import ReadingProgress from '@/components/ReadingProgress'
import AdminButton from '@/components/AdminButton'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import EditableBlocks from '@/components/EditableBlocks'
import { getDetail, isAdmin } from '@/lib/details'
import { getSections } from '@/lib/sections'
import { getModule } from '@/modules/registry'
import { asStr } from '@/modules/helpers'

async function find(id: string) {
  for (const s of await getSections()) {
    const item = s.items.find((it) => it._id === id)
    const mod = getModule(s.kind)
    if (item && mod) return { s, item, mod }
  }
  return null
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const f = await find((await params).id)
  return { title: f ? f.mod.itemTitle(f.item) : 'Detail' }
}

/** Halaman detail untuk satu item (achievement, pengalaman, fokus, ...), isinya diedit ala Notion. */
export default async function ItemDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const found = await find(id)
  if (!found) notFound()
  const { s, item, mod } = found
  const key = `item-${id}`
  const [blocks, admin] = await Promise.all([getDetail(key), isAdmin()])
  if (blocks.length === 0 && !admin) notFound() // pengunjung tidak melihat halaman kosong

  const meta = [asStr(item.issuer), asStr(item.org), asStr(item.period), asStr(item.year)].filter(Boolean).join(' · ')
  const summary = asStr(item.description) || asStr(item.desc)

  return (
    <main
      className="min-h-screen bg-[#f7f6f2] text-slate-800"
      style={{ backgroundImage: 'radial-gradient(#d6d3cb 1px, transparent 1px)', backgroundSize: '28px 28px' }}
    >
      <ReadingProgress />
      <article className="mx-auto max-w-3xl px-6 pb-20 pt-16">
        <Link
          href={`/#${s.kind}`}
          className="mb-10 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-slate-500 transition-colors hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" /> {s.title || mod.title}
        </Link>
        {meta && <p className="mb-3 font-mono text-xs text-blue-600">{meta}</p>}
        <h1 className="mb-4 text-4xl font-extrabold tracking-tight text-slate-900 md:text-5xl">{mod.itemTitle(item)}</h1>
        {summary && <p className="mb-8 text-lg text-slate-600">{summary}</p>}
        <EditableBlocks detailKey={key} initial={blocks} canEdit={admin} />
      </article>
      <AdminButton />
    </main>
  )
}
