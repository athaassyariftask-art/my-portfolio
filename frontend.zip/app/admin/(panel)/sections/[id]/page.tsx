import { notFound } from 'next/navigation'
import SectionEditor from '@/components/admin/SectionEditor'
import { getAdminSection } from '@/lib/sections'

export default async function EditSection({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const section = await getAdminSection(id)
  if (!section || section.id === null) notFound()

  return (
    <>
      <h1 className="mb-8 text-3xl font-extrabold tracking-tight text-slate-900">Edit section</h1>
      <SectionEditor
        id={section.id}
        kind={section.kind}
        title={section.title}
        isVisible={section.is_visible}
        initialItems={section.items}
      />
    </>
  )
}
