import SectionList from '@/components/admin/SectionList'
import { getAdminSections } from '@/lib/sections'

export default async function AdminSections() {
  const sections = await getAdminSections()

  return (
    <>
      <h1 className="mb-2 text-3xl font-extrabold tracking-tight text-slate-900">Section</h1>
      <p className="mb-8 text-slate-500">
        Blok di halaman depan. Atur urutan, sembunyikan, atau tambah jenis baru (Achievement, Toolbox, dll).
      </p>
      <SectionList
        sections={sections.map((s) => ({
          id: s.id as number,
          kind: s.kind,
          title: s.title,
          is_visible: s.is_visible,
          order: s.order,
          count: s.items.length,
        }))}
      />
    </>
  )
}
