import Link from 'next/link'
import LogoutButton from '@/components/admin/LogoutButton'
import { requireAdmin } from '@/lib/auth'

export const metadata = { title: 'Admin', robots: { index: false, follow: false } }

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin() // belum login -> redirect ke /admin/login

  const nav = 'font-mono text-xs uppercase tracking-widest text-slate-500 transition-colors hover:text-slate-900'
  return (
    <div className="min-h-screen bg-[#f7f6f2] text-slate-800">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <nav className="flex items-center gap-6">
            <Link href="/admin" className={nav}>Project</Link>
            <Link href="/admin/sections" className={nav}>Section</Link>
            <Link href="/admin/profile" className={nav}>Profil</Link>
            <Link href="/admin/messages" className={nav}>Pesan</Link>
            <Link href="/" target="_blank" className={nav}>Lihat situs ↗</Link>
          </nav>
          <LogoutButton />
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-6 py-10">{children}</main>
    </div>
  )
}
