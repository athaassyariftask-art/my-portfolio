import CvUpload from '@/components/admin/CvUpload'
import PhotoUpload from '@/components/admin/PhotoUpload'
import ProfileForm from '@/components/admin/ProfileForm'
import { getProfile } from '@/lib/profile'

export default async function AdminProfile() {
  // Form diisi nilai yang sedang tampil di website (database, atau bawaan site.config.ts)
  const profile = await getProfile()

  return (
    <>
      <h1 className="mb-2 text-3xl font-extrabold tracking-tight text-slate-900">Profil</h1>
      <p className="mb-8 text-slate-500">Teks di halaman depan. Kolom yang dikosongkan akan memakai nilai bawaan.</p>
      <PhotoUpload photo={profile.photo} />
      <CvUpload cv={profile.cv} />
      <ProfileForm initial={profile} />
    </>
  )
}
