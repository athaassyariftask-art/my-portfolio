import ProjectForm from '@/components/admin/ProjectForm'

export default function NewProject() {
  return (
    <>
      <h1 className="mb-8 text-3xl font-extrabold tracking-tight text-slate-900">Project baru</h1>
      <ProjectForm />
    </>
  )
}
