import { notFound } from 'next/navigation'
import ProjectForm from '@/components/admin/ProjectForm'
import { getProject } from '@/lib/projects'

export default async function EditProject({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const project = await getProject(id, { auth: true })
  if (!project) notFound()

  return (
    <>
      <h1 className="mb-8 text-3xl font-extrabold tracking-tight text-slate-900">Edit project</h1>
      <ProjectForm project={project} />
    </>
  )
}
