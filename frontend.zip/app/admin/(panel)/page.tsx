import Link from 'next/link'
import DeleteButton from '@/components/admin/DeleteButton'
import { btnPrimary } from '@/components/admin/ui'
import { getProjects } from '@/lib/projects'

export default async function AdminProjects() {
  const projects = await getProjects({ auth: true }) // staff melihat draft juga

  return (
    <>
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">Project</h1>
        <Link href="/admin/projects/new" className={btnPrimary}>+ Tambah project</Link>
      </div>

      {projects.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-slate-300 p-10 text-slate-500">
          Belum ada project. Klik “Tambah project” untuk mulai.
        </p>
      ) : (
        <ul className="divide-y divide-slate-200 overflow-hidden rounded-3xl border border-slate-200 bg-white">
          {projects.map((p) => (
            <li key={p.id} className="flex items-center gap-4 p-4">
              <div className="h-14 w-24 shrink-0 overflow-hidden rounded-xl bg-gradient-to-br from-emerald-100 via-violet-100 to-blue-100">
                {p.cover && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.cover} alt="" className="h-full w-full object-cover" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-slate-900">{p.title}</p>
                <p className="flex gap-2 font-mono text-xs text-slate-500">
                  <span>#{p.order}</span>
                  {!p.published && <span className="text-amber-600">DRAFT</span>}
                  {p.featured && <span className="text-blue-600">FEATURED</span>}
                  <span>{p.date}</span>
                </p>
              </div>
              <Link href={`/admin/projects/${p.id}`} className="text-sm font-semibold text-blue-600 hover:underline">
                Edit
              </Link>
              <DeleteButton endpoint={`projects/${p.id}`} name={p.title} />
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
