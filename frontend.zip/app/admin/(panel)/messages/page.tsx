import DeleteButton from '@/components/admin/DeleteButton'
import { apiGet, unwrapList } from '@/lib/api'

type Message = { id: number; name: string; email: string; message: string; created_at: string }

export default async function AdminMessages() {
  const data = await apiGet<unknown>('/contact/', { auth: true })
  const messages = unwrapList<Message>(data)

  return (
    <>
      <h1 className="mb-8 text-3xl font-extrabold tracking-tight text-slate-900">Pesan masuk</h1>

      {messages.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-slate-300 p-10 text-slate-500">Belum ada pesan.</p>
      ) : (
        <ul className="space-y-4">
          {messages.map((m) => (
            <li key={m.id} className="rounded-3xl border border-slate-200 bg-white p-6">
              <div className="mb-3 flex items-start justify-between gap-4">
                <div>
                  <p className="font-semibold text-slate-900">{m.name}</p>
                  <a href={`mailto:${m.email}`} className="text-sm text-blue-600 hover:underline">{m.email}</a>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-xs text-slate-400">{m.created_at.slice(0, 10)}</span>
                  <DeleteButton endpoint={`contact/${m.id}`} name={`pesan dari ${m.name}`} />
                </div>
              </div>
              <p className="whitespace-pre-line text-slate-700">{m.message}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
