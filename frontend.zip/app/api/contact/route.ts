import { NextResponse } from 'next/server'
import { API_URL } from '@/lib/api'

// Form kontak publik -> Django (Django membatasi 5 pesan/jam per IP)
export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ detail: 'Data tidak valid.' }, { status: 400 })

  const { name, email, message } = body as Record<string, string>
  try {
    const res = await fetch(`${API_URL}/contact/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, message }),
      cache: 'no-store',
    })
    return NextResponse.json(await res.json().catch(() => ({})), { status: res.status })
  } catch {
    return NextResponse.json({ detail: 'Backend tidak bisa dihubungi.' }, { status: 502 })
  }
}
