import { NextResponse } from 'next/server'
import { API_URL, TOKEN_COOKIE } from '@/lib/api'

export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({}))

  let res: Response
  try {
    res = await fetch(`${API_URL}/auth/token/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    })
  } catch {
    return NextResponse.json({ error: 'Backend tidak bisa dihubungi. Pastikan Django sedang jalan.' }, { status: 502 })
  }

  if (!res.ok) {
    const tooMany = res.status === 429
    return NextResponse.json(
      { error: tooMany ? 'Terlalu banyak percobaan. Coba lagi sebentar.' : 'Username atau password salah.' },
      { status: tooMany ? 429 : 401 }
    )
  }

  const { access } = await res.json()
  const out = NextResponse.json({ ok: true })
  // httpOnly: token tidak bisa dibaca JavaScript di browser (aman dari XSS)
  out.cookies.set(TOKEN_COOKIE, access, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 12,
  })
  return out
}
