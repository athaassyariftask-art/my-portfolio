import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { API_URL, TOKEN_COOKIE } from './api'

/** Dipanggil di layout admin: belum login / token kadaluarsa -> ke halaman login. */
export async function requireAdmin() {
  const token = (await cookies()).get(TOKEN_COOKIE)?.value
  if (!token) redirect('/admin/login')

  // /contact/ hanya bisa dibuka staff, jadi cocok untuk memvalidasi token
  let status = 0
  try {
    const res = await fetch(`${API_URL}/contact/`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: 'no-store',
    })
    status = res.status
  } catch {
    // backend mati: biarkan halaman tampil, aksi simpan akan menampilkan error sendiri
  }
  if (status === 401 || status === 403) redirect('/admin/login')
}
