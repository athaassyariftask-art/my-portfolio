import { cookies } from 'next/headers'
import type { Item } from '@/modules/types'
import { apiGet } from './api'
import { TOKEN_COOKIE } from './api'
import type { Block } from './pages'

/** Isi detail (blok) untuk satu key, mis. "project-3", "item-ab12cd34", "about". Kosong kalau belum ada. */
export async function getDetail(key: string): Promise<Block[]> {
  const d = await apiGet<{ blocks?: Block[] }>(`/details/${encodeURIComponent(key)}/`)
  return Array.isArray(d?.blocks) ? d.blocks : []
}

/** Pengunjung yang sedang login sebagai admin (cek cookie; Django tetap memeriksa token saat menyimpan). */
export async function isAdmin(): Promise<boolean> {
  return Boolean((await cookies()).get(TOKEN_COOKIE)?.value)
}

export type DetailContext = { keys: string[]; admin: boolean }

/** Dipakai halaman yang menampilkan Sections: key mana yang sudah punya isi + apakah pengunjung admin. */
export async function getDetailContext(): Promise<DetailContext> {
  const [d, admin] = await Promise.all([apiGet<{ keys?: string[] }>('/details/'), isAdmin()])
  return { keys: Array.isArray(d?.keys) ? d.keys : [], admin }
}

export const itemDetailKey = (item: Item): string | null => {
  const id = item._id
  return typeof id === 'string' && id ? `item-${id}` : null
}

/** Tautan ke halaman detail item. Pengunjung biasa hanya melihatnya kalau sudah ada isinya. */
export function makeDetailHref(ctx: DetailContext) {
  return (item: Item): string | null => {
    const key = itemDetailKey(item)
    if (!key) return null
    return ctx.admin || ctx.keys.includes(key) ? `/d/${key.slice(5)}` : null
  }
}
