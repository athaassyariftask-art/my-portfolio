import { cookies } from 'next/headers'

// Alamat backend Django (hanya dipakai di server Next.js, tidak bocor ke browser)
export const API_URL = process.env.API_URL ?? 'http://127.0.0.1:8000/api'
export const TOKEN_COOKIE = 'porto_admin'

/** GET ke Django. auth: true = kirim token admin dari cookie. Gagal -> null (website tetap jalan). */
export async function apiGet<T>(path: string, opts?: { auth?: boolean }): Promise<T | null> {
  const headers: Record<string, string> = {}
  if (opts?.auth) {
    const token = (await cookies()).get(TOKEN_COOKIE)?.value
    if (token) headers.Authorization = `Bearer ${token}`
  }
  try {
    const res = await fetch(`${API_URL}${path}`, { headers, cache: 'no-store' })
    if (!res.ok) return null
    return (await res.json()) as T
  } catch {
    return null
  }
}

/** Django bisa mengembalikan list biasa atau {results: [...]} (kalau pagination aktif). */
export function unwrapList<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[]
  const results = (data as { results?: T[] } | null)?.results
  return Array.isArray(results) ? results : []
}
