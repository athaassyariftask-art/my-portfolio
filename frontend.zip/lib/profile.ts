import { site as defaults } from '@/site.config'
import { apiGet } from './api'

export type Site = typeof defaults & { cv: string } // cv: alamat PDF dari Admin → Profil (kosong = tombol tidak tampil)

const str = (v: unknown, fallback: string) => (typeof v === 'string' && v.trim() ? v : fallback)
const arr = <T,>(v: unknown, fallback: T[]): T[] => (Array.isArray(v) && v.length ? (v as T[]) : fallback)

/**
 * Profil = isi dari database (diedit lewat /admin), dengan site.config.ts sebagai cadangan.
 * Kolom yang kosong di database otomatis memakai nilai bawaan, jadi website tidak pernah kosong.
 */
export async function getProfile(): Promise<Site> {
  const d = await apiGet<Record<string, unknown>>('/profile/')
  if (!d) return { ...defaults, cv: '' }

  return {
    name: str(d.name, defaults.name),
    role: str(d.role, defaults.role),
    affiliation: str(d.affiliation, defaults.affiliation),
    email: str(d.email, defaults.email),
    // Foto dari database (/media/... lewat rewrite Next); kalau belum diupload, pakai site.config.ts
    photo: str(d.photo, defaults.photo),
    // Dibuat relatif (/media/...) supaya lewat alamat website yang sama
    cv: typeof d.cv === 'string' && d.cv ? new URL(d.cv, 'http://x').pathname : '',
    links: arr(d.links, defaults.links),
    headline: {
      lead: str(d.headline_lead, defaults.headline.lead),
      accent: str(d.headline_accent, defaults.headline.accent),
    },
    intro: str(d.intro, defaults.intro),
  }
}
