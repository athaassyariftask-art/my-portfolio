import type { Item } from '@/modules/types'
import { modules } from '@/modules/registry'
import { apiGet, unwrapList } from './api'

export type Section = {
  id: number | null // null = bawaan (belum ada di database)
  kind: string
  title: string
  items: Item[]
  is_visible: boolean
  order: number
}

/** Section bawaan dari registry: dipakai kalau database kosong atau backend mati. */
export function defaultSections(): Section[] {
  return modules
    .filter((m) => m.defaultOn !== false)
    .map((m, i) => ({
      id: null,
      kind: m.kind,
      title: m.title,
      items: m.defaults as Item[],
      is_visible: true,
      order: i * 10,
    }))
}

type Raw = Partial<Section> & { id: number; kind: string }

const map = (r: Raw): Section => ({
  id: r.id,
  kind: r.kind,
  title: r.title ?? '',
  items: Array.isArray(r.items) ? r.items : [],
  is_visible: r.is_visible ?? true,
  order: r.order ?? 0,
})

/** Untuk website publik. Database kosong atau backend mati -> section bawaan. */
export async function getSections(): Promise<Section[]> {
  const data = await apiGet<unknown>('/sections/')
  if (!data) return defaultSections()
  const list = unwrapList<Raw>(data).map(map)
  return list.length ? list : defaultSections()
}

/** Untuk admin: apa adanya dari database (termasuk yang disembunyikan). */
export async function getAdminSections(): Promise<Section[]> {
  const data = await apiGet<unknown>('/sections/', { auth: true })
  return data ? unwrapList<Raw>(data).map(map) : []
}

export async function getAdminSection(id: string): Promise<Section | null> {
  const data = await apiGet<Raw>(`/sections/${encodeURIComponent(id)}/`, { auth: true })
  return data ? map(data) : null
}
