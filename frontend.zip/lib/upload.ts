import { readError } from '@/components/admin/ui'

/** Upload gambar ke Django lewat proxy admin. Mengembalikan alamat /media/... */
export async function uploadImage(file: File): Promise<string> {
  if (file.size > 8 * 1024 * 1024) throw new Error('Ukuran maksimal 8 MB.')
  const fd = new FormData()
  fd.append('file', file)
  const res = await fetch('/api/admin/uploads', { method: 'POST', body: fd })
  if (!res.ok) throw new Error(await readError(res))
  return (await res.json()).url as string
}

/** Upload video (mp4/webm/mov, maks 100 MB). Mengembalikan alamat /media/... */
export async function uploadVideo(file: File): Promise<string> {
  if (file.size > 100 * 1024 * 1024) throw new Error('Ukuran video maksimal 100 MB.')
  const fd = new FormData()
  fd.append('file', file)
  const res = await fetch('/api/admin/uploads/video', { method: 'POST', body: fd })
  if (!res.ok) throw new Error(await readError(res))
  return (await res.json()).url as string
}
