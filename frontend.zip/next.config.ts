import type { NextConfig } from "next";

// Alamat Django (tanpa /api). Dipakai untuk meneruskan /media/... supaya foto yang diupload
// terbaca dari alamat yang sama dengan website (penting untuk tekstur 3D di lanyard: tanpa CORS).
const apiOrigin = new URL(process.env.API_URL ?? "http://127.0.0.1:8000/api").origin;

const nextConfig: NextConfig = {
  async rewrites() {
    return [{ source: "/media/:path*", destination: `${apiOrigin}/media/:path*` }];
  },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
