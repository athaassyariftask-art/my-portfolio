'use client'

import { useRouter } from 'next/navigation'

export default function LogoutButton() {
  const router = useRouter()
  return (
    <button
      onClick={async () => {
        await fetch('/api/auth/logout', { method: 'POST' })
        router.push('/admin/login')
        router.refresh()
      }}
      className="font-mono text-xs uppercase tracking-widest text-slate-500 transition-colors hover:text-rose-600"
    >
      Logout
    </button>
  )
}
