'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import type { Item } from '@/modules/types'
import { getModule, modules } from '@/modules/registry'
import DeleteButton from './DeleteButton'
import { btnGhost, btnPrimary, input, readError } from './ui'

type Row = { id: number; kind: string; title: string; is_visible: boolean; order: number; count: number }

async function send(method: string, url: string, body?: unknown) {
  const res = await fetch(`/api/admin/${url}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  if (!res.ok) throw new Error(await readError(res))
  return res.status === 204 ? null : res.json()
}

export default function SectionList({ sections }: { sections: Row[] }) {
  const router = useRouter()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [kind, setKind] = useState(modules.find((m) => m.defaultOn === false)?.kind ?? modules[0].kind)

  async function run(fn: () => Promise<void>) {
    setBusy(true)
    setError('')
    try {
      await fn()
      router.refresh()
    } catch (e) {
      setError((e as Error).message)
    }
    setBusy(false)
  }

  // Urutan dinomori ulang (0, 10, 20, ...) supaya tidak bentrok kalau banyak yang bernilai sama.
  const move = (i: number, d: -1 | 1) =>
    run(async () => {
      const j = i + d
      if (j < 0 || j >= sections.length) return
      const next = [...sections]
      ;[next[i], next[j]] = [next[j], next[i]]
      await Promise.all(
        next.map((s, idx) => (s.order !== idx * 10 ? send('PATCH', `sections/${s.id}`, { order: idx * 10 }) : null)),
      )
    })

  const toggle = (s: Row) => run(async () => void (await send('PATCH', `sections/${s.id}`, { is_visible: !s.is_visible })))

  const seedDefaults = () =>
    run(async () => {
      let order = 0
      for (const m of modules.filter((x) => x.defaultOn !== false)) {
        await send('POST', 'sections', { kind: m.kind, title: m.title, items: m.defaults as Item[], order, is_visible: true })
        order += 10
      }
    })

  const add = () =>
    run(async () => {
      const m = getModule(kind)
      if (!m) return
      const max = sections.reduce((n, s) => Math.max(n, s.order), -10)
      const created = (await send('POST', 'sections', {
        kind: m.kind,
        title: m.title,
        items: m.defaults as Item[],
        order: max + 10,
        is_visible: true,
      })) as { id: number }
      router.push(`/admin/sections/${created.id}`)
    })

  return (
    <div className="space-y-8">
      {sections.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-300 p-10">
          <p className="mb-4 text-slate-600">
            Belum ada section di database, jadi website memakai susunan bawaan. Buat dulu supaya bisa kamu atur.
          </p>
          <button disabled={busy} onClick={seedDefaults} className={btnPrimary}>Buat dari bawaan</button>
        </div>
      ) : (
        <ul className="divide-y divide-slate-200 overflow-hidden rounded-3xl border border-slate-200 bg-white">
          {sections.map((s, i) => {
            const mod = getModule(s.kind)
            return (
              <li key={s.id} className="flex items-center gap-4 p-4">
                <div className="flex shrink-0 flex-col text-xs font-semibold text-slate-400">
                  <button disabled={busy || i === 0} onClick={() => move(i, -1)} className="hover:text-slate-900 disabled:opacity-30">↑</button>
                  <button disabled={busy || i === sections.length - 1} onClick={() => move(i, 1)} className="hover:text-slate-900 disabled:opacity-30">↓</button>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-slate-900">{s.title}</p>
                  <p className="flex gap-2 font-mono text-xs text-slate-500">
                    <span>{mod ? mod.label : `modul tidak dikenal: ${s.kind}`}</span>
                    {mod && !mod.managedElsewhere && <span>{s.count} item</span>}
                    {!s.is_visible && <span className="text-amber-600">DISEMBUNYIKAN</span>}
                  </p>
                </div>
                <button disabled={busy} onClick={() => toggle(s)} className="text-sm font-semibold text-slate-500 hover:text-slate-900">
                  {s.is_visible ? 'Sembunyikan' : 'Tampilkan'}
                </button>
                <Link href={`/admin/sections/${s.id}`} className="text-sm font-semibold text-blue-600 hover:underline">Edit</Link>
                <DeleteButton endpoint={`sections/${s.id}`} name={s.title} />
              </li>
            )
          })}
        </ul>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <select value={kind} onChange={(e) => setKind(e.target.value)} className={`${input} w-auto`}>
          {modules.map((m) => (
            <option key={m.kind} value={m.kind}>{m.label} — {m.description}</option>
          ))}
        </select>
        <button disabled={busy} onClick={add} className={btnGhost}>+ Tambah section</button>
      </div>

      {error && <p className="whitespace-pre-line rounded-xl bg-rose-50 p-4 text-sm text-rose-700">{error}</p>}
    </div>
  )
}
