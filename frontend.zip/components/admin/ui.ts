// Kelas Tailwind bersama untuk form admin
export const input =
  'w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none'
export const label = 'mb-1.5 block font-mono text-xs uppercase tracking-widest text-slate-500'
export const btnPrimary =
  'inline-flex items-center justify-center rounded-full bg-slate-900 px-6 py-2.5 font-semibold text-white transition-colors hover:bg-blue-600 disabled:opacity-50'
export const btnGhost =
  'inline-flex items-center justify-center rounded-full border border-slate-300 px-5 py-2.5 font-semibold text-slate-700 transition-colors hover:border-slate-900'

/** Ubah respons error DRF ({field: [pesan]}) jadi teks yang enak dibaca. */
export async function readError(res: Response): Promise<string> {
  if (res.status === 401) return 'Sesi habis. Silakan login lagi.'
  try {
    const data = await res.json()
    if (typeof data?.detail === 'string') return data.detail
    return Object.entries(data)
      .map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(' ') : String(v)}`)
      .join('\n')
  } catch {
    return `Gagal (kode ${res.status}).`
  }
}
