'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { btnGhost, label, readError } from './ui'

/** Upload / hapus foto profil (muncul di kartu lanyard). Langsung tersimpan begitu file dipilih. */
export default function PhotoUpload({ photo }: { photo: string }) {
  const router = useRouter()
  const input = useRef<HTMLInputElement>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [broken, setBroken] = useState(false)

  async function upload(file: File) {
    if (file.size > 8 * 1024 * 1024) return setError('Ukuran maksimal 8 MB.')
    setBusy(true)
    setError('')
    const fd = new FormData()
    fd.append('photo', file)
    const res = await fetch('/api/admin/profile/photo', { method: 'PUT', body: fd })
    if (!res.ok) setError(await readError(res))
    else {
      setBroken(false)
      router.refresh()
    }
    setBusy(false)
    if (input.current) input.current.value = ''
  }

  async function remove() {
    if (!confirm('Hapus foto profil?')) return
    setBusy(true)
    setError('')
    const res = await fetch('/api/admin/profile/photo', { method: 'DELETE' })
    if (!res.ok) setError(await readError(res))
    else router.refresh()
    setBusy(false)
  }

  return (
    <div className="mb-10">
      <p className={label}>Foto profil (di kartu lanyard)</p>
      <div className="flex items-center gap-5">
        <div className="flex h-32 w-24 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 text-xs text-slate-400">
          {photo && !broken ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={photo} src={photo} alt="" className="h-full w-full object-cover" onError={() => setBroken(true)} />
          ) : (
            'Belum ada'
          )}
        </div>
        <div className="space-y-3">
          <input
            ref={input}
            type="file"
            accept="image/*"
            disabled={busy}
            onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
            className="block text-sm text-slate-600"
          />
          <p className="font-mono text-xs text-slate-400">Potret, rasio ±4:5, maks 8 MB. Tersimpan otomatis.</p>
          <button type="button" disabled={busy} onClick={remove} className={btnGhost}>Hapus foto</button>
        </div>
      </div>
      {error && <p className="mt-3 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
    </div>
  )
}
