'use client'

import Link from 'next/link'
import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import type { Item } from '@/modules/types'
import { getModule } from '@/modules/registry'
import ItemsEditor, { findMissing } from './ItemsEditor'
import { btnPrimary, input, label, readError } from './ui'

type Props = { id: number; kind: string; title: string; isVisible: boolean; initialItems: Item[] }

export default function SectionEditor({ id, kind, title: t0, isVisible, initialItems }: Props) {
  const router = useRouter()
  const mod = getModule(kind)
  const [title, setTitle] = useState(t0)
  const [visible, setVisible] = useState(isVisible)
  const items = useRef<Item[]>(initialItems)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)

  if (!mod) {
    return (
      <p className="rounded-2xl bg-amber-50 p-5 text-sm text-amber-800">
        Modul "{kind}" tidak ada di frontend/modules/registry.ts, jadi tidak bisa diedit dan tidak ditampilkan di website.
      </p>
    )
  }

  async function save(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setSaved(false)
    const missing = mod ? findMissing(mod.fields, items.current, mod.itemLabel) : null
    if (missing) return setError(missing)

    setBusy(true)
    const body: Record<string, unknown> = { title, is_visible: visible }
    if (!mod?.managedElsewhere) body.items = items.current
    const res = await fetch(`/api/admin/sections/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (!res.ok) setError(await readError(res))
    else {
      setSaved(true)
      router.refresh()
    }
    setBusy(false)
  }

  return (
    <form onSubmit={save} className="space-y-8">
      <div className="grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <label className={label} htmlFor="title">Judul section</label>
          <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} className={input} required />
        </div>
        <label className="flex items-center gap-2 pb-3 text-sm text-slate-700">
          <input type="checkbox" checked={visible} onChange={(e) => setVisible(e.target.checked)} />
          Tampilkan di website
        </label>
      </div>

      {mod.managedElsewhere ? (
        <p className="rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-600">
          {mod.managedElsewhere.text}{' '}
          <Link href={mod.managedElsewhere.href} className="font-semibold text-blue-600 hover:underline">
            Buka
          </Link>
        </p>
      ) : (
        <ItemsEditor
          fields={mod.fields}
          initial={initialItems}
          onChange={(v) => (items.current = v)}
          itemLabel={mod.itemLabel}
          itemTitle={mod.itemTitle}
        />
      )}

      {error && <p className="whitespace-pre-line rounded-xl bg-rose-50 p-4 text-sm text-rose-700">{error}</p>}
      {saved && <p className="rounded-xl bg-emerald-50 p-4 text-sm text-emerald-700">Tersimpan. Website sudah memakai data terbaru.</p>}

      <div className="flex items-center gap-4">
        <button disabled={busy} className={btnPrimary}>{busy ? 'Menyimpan…' : 'Simpan section'}</button>
        <Link href="/admin/sections" className="text-sm font-semibold text-slate-500 hover:text-slate-900">← Semua section</Link>
      </div>
    </form>
  )
}
