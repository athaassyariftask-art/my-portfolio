import { makeDetailHref, type DetailContext } from '@/lib/details'
import Reveal from '@/components/Reveal'
import type { Project } from '@/lib/projects'
import type { Section } from '@/lib/sections'
import { getModule } from '@/modules/registry'
import type { SectionModule } from '@/modules/types'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Picked = { s: Section; mod: SectionModule<any>; anchor: string }

/**
 * Pilih section yang tampil di halaman tertentu: modulnya dikenal, `page`-nya cocok,
 * tidak disembunyikan, dan punya isi (kecuali alwaysShow). Anchor = nama modul (#projects),
 * kalau kembar ditambah id.
 */
export function pickSections(sections: Section[], page: 'home' | 'about'): Picked[] {
  const seen = new Set<string>()
  return sections.flatMap((s) => {
    const mod = getModule(s.kind)
    if (!mod || (mod.page ?? 'home') !== page) return []
    if (!s.is_visible || (!mod.alwaysShow && s.items.length === 0)) return []
    const anchor = seen.has(s.kind) ? `${s.kind}-${s.id}` : s.kind
    seen.add(s.kind)
    return [{ s, mod, anchor }]
  })
}

function SectionTitle({ n, label, calm }: { n: string; label: string; calm?: boolean }) {
  if (!calm) {
    // Tema pop (halaman depan): lencana bernomor + judul tebal + garis tinta
    return (
      <Reveal>
        <div className="mb-10 flex items-center gap-4">
          <span className="pop-badge pop-orange">{n}</span>
          <h2 className="pop-display text-3xl uppercase md:text-4xl">{label}</h2>
          <span className="h-[3px] flex-1 bg-[#141414]" />
        </div>
      </Reveal>
    )
  }
  return (
    <Reveal>
      <div className="mb-10 flex items-center gap-4 font-mono text-xs uppercase tracking-[0.2em] text-slate-500">
        <span className="text-blue-600">{n}</span>
        <span>{label}</span>
        <span className="h-px flex-1 bg-slate-200" />
      </div>
    </Reveal>
  )
}

export default function Sections({
  items,
  projects,
  narrow,
  detail = { keys: [], admin: false },
}: {
  items: Picked[]
  projects: Project[]
  narrow?: boolean
  detail?: DetailContext
}) {
  const detailHref = makeDetailHref(detail)
  return (
    <>
      {items.map(({ s, mod, anchor }, i) => (
        <section
          key={anchor}
          id={anchor}
          className={`relative z-10 mx-auto ${narrow ? 'max-w-3xl' : 'max-w-6xl'} scroll-mt-8 px-6 pb-28`}
        >
          <SectionTitle n={String(i + 1).padStart(2, '0')} label={s.title || mod.title} calm={narrow} />
          <mod.View items={s.items} projects={projects} detailHref={detailHref} />
        </section>
      ))}
    </>
  )
}
